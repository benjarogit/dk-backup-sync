# -*- coding: utf-8 -*-
# resources.lib - Auto FTP Sync shared modules
# Gemeinsame Basis: from resources.lib.common import ADDON, L, log, safe_get_string, safe_get_bool
